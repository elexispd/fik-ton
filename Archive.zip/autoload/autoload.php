<?php 
spl_autoload_register(function($classname){

})
?>